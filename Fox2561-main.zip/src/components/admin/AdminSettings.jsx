const AdminSettings = () => {
  return (
    <div>
      <h2 className="text-xl font-bold">إعدادات المسؤول</h2>
      <p>هذه الصفحة مخصصة لإعدادات المسؤول.</p>
    </div>
  );
};

export default AdminSettings;
